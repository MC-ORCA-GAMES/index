# NEXUS: BREACH — Handoff

Stand: 22.09.2026 (Fortsetzung). Teil des MC ORCA Games Portfolios, bewusst NICHT
mit Supabase/Konto/MOGC verbunden.

## Was in dieser Session fertiggestellt wurde

**Begehbarer Vorraum mit Säulen vor dem Ausgang (Zufallslauf-Modus).**

Vorher gab es am Ausgang nur eine einzelne Zellenbreite Tür in der Randwand —
kein Raum zum Bewegen, kein Versteckspiel vor dem Boss. Jetzt:

- **`carveMaze(size, blockedIdx)`** akzeptiert jetzt optional ein Set reservierter
  Zellen, die der Recursive-Backtracker nie betritt (Wert `3` im Grid). Damit kann
  die Fläche eines Vorraums *vor* dem eigentlichen Carven gesperrt werden — die
  Maze wächst organisch drumherum, statt hinterher Löcher in eine fertige Karte
  zu stanzen (das hätte immer riskiert, einen für den Rest der Karte nötigen
  Gang zu kappen).
- **`planAntechamber(size, doorCand)`**: plant Lage/Größe des Vorraums an der
  vorher gefundenen Ausgangs-Randzelle. Raumgröße richtet sich nach der
  Kartengröße (3×3 bei kleinen Sektoren bis 9×9 bei großen), schrumpft
  automatisch, wenn am Kartenrand nicht genug Platz ist, und gibt `null`
  zurück (→ Fallback auf alte Einzelzellen-Tür), wenn selbst 3×3 nicht passt.
- **`finishAntechamber(g, size, plan)`**: trägt den Innenraum als begehbaren
  Flur ein, setzt genau einen Zugang (Ring bleibt sonst Wand), platziert
  Säulen im Innern (Rand bleibt frei, damit man an Tür/Zugang immer
  vorbeikommt) — nur ab Raumgröße 5×5 aufwärts, 3×3 bleibt Säulen-frei.
- **Zwei-Durchlauf-Generierung**: Durchlauf 1 baut eine Test-Maze nur, um die
  beste Ausgangsposition zu finden; Durchlauf 2 baut die echte Maze mit der
  Vorraum-Fläche als Sperrzone. Nach dem Zusammenbau läuft ein
  Sicherheitsnetz-Check (volle Erreichbarkeits-Prüfung); im (praktisch nie
  auftretenden) Fehlerfall fällt der Code komplett auf die alte,
  bewährte Einzelzellen-Tür zurück.
- **Boss-Platzierung**: Wenn ein Vorraum gebaut wurde, steht der Kern-Wächter
  jetzt im Vorraum selbst (möglichst zentral, weicht Säulen/Eingang/Türschwelle
  aus) — bewacht also den ganzen Raum, nicht nur eine einzelne Zelle davor.
  Ohne Vorraum (Fallback) bleibt die bisherige Logik (Boss nahe am Ausgang).
- **Item-/Gegner-Platzierung** schließt Zugangszelle und Türschwelle des
  Vorraums jetzt aus, damit dort nichts Zufälliges landet.

### Testergebnis (Node-Simulation, kein Browsertest)

2100 Durchläufe über alle Tiefen 1–30, alle vier Größenstufen:
- **0 abgeschnittene Kartenteile** — die Karte ist in jedem Lauf aus einem Stück.
- **1843 von 2100 Läufen** bekommen einen echten Vorraum (Rest fällt sauber auf
  die alte Einzelzellen-Tür zurück, meist bei sehr kleinen Sektoren ohne Platz).
- **1659 der 1843 Vorräume** haben Säulen (ab Raumgröße 5×5).
- Raumgrößen-Verteilung: 3×3 in 184 Fällen, 5×5 in 87, 7×7 in 388, 9×9 in 1184.
- Boss wird in jedem Fall platziert, wo `depth % 3 === 0` gilt (700/700).

## Bildschirm füllt jetzt immer randlos (kein festes 16:10 mehr)

Vorher war die Bühne (`#stage`) fest auf 16:10 (`aspect-ratio:16/10`, Breite
`min(100vw,160vh)`) begrenzt — auf Bildschirmen, die davon abweichen (z. B.
Ultrawide-Monitore), blieben schwarze Seitenstreifen übrig.

Jetzt füllt `#stage` immer `100vw` × `100dvh` (voller Bildschirm). Das Canvas
(`#view`) wird per `object-fit:cover` reinskaliert: es rendert weiterhin intern
in der festen Auflösung 960×600 (16:10, unverändert im JS — `const W=960,
H=600`), wird aber verzerrungsfrei so weit vergrößert, dass es die ganze
Bühne ausfüllt. Bei abweichendem Seitenverhältnis wird dabei minimal oben/
unten bzw. links/rechts beschnitten (kein Verzerren, keine schwarzen Balken).
HUD-Elemente (`cqw`-Einheiten, `container-type:inline-size` auf `#stage`)
skalieren automatisch mit der jetzt immer vollen Bildschirmbreite mit.

Kein Browsertest — nur Syntax-/Struktur-Check der CSS-Änderung. Sollte auf
Bildschirmen mit sehr extremem Seitenverhältnis (sehr schmal/hoch, z. B.
Hochformat-Handy) mehr als üblich vom oberen/unteren Bildrand abschneiden;
falls das im Test auffällt, ließe sich mit `object-position` nachjustieren,
oder alternativ die Render-Auflösung selbst dynamisch ans Seitenverhältnis
anpassen (größerer Umbau, siehe unten).

## Mehrere Etagen pro Standort (Keller / Erdgeschoss / Stockwerke)

Umgesetzt auf Wunsch: Ab einer bestimmten Tiefe besteht ein Sektor im
Zufallslauf nicht mehr aus nur einer Maze-Ebene, sondern aus mehreren
übereinanderliegenden Etagen, die man per Treppe verbindet — man startet
z. B. im Keller und klettert Stück für Stück hoch bis zum Sektor mit dem
eigentlichen Ausgang.

**Wichtig zu verstehen:** Das ist **kein echtes 3D mit Blick durch ein Loch
nach oben** — der Raycaster ist klassisch (eine Grid-Ebene, ein Boden, eine
Decke pro Sektor, wie altes Doom). Eine "Etage" ist technisch eine eigene,
komplett neu generierte Karte; eine Treppe ist ein Spezial-Feld, das beim
Erreichen per Fade-Transition auf die nächsthöhere Karte umschaltet — exakt
das gleiche Prinzip, das der Zufallslauf schon für den Wechsel zwischen
Tiefen benutzt hat ("Weiter — Tiefe X"), nur jetzt zusätzlich *innerhalb*
einer Tiefe.

### Wie es funktioniert

- **`floorsForDepth(depth)`**: legt fest, wie viele Etagen ein Standort bei
  dieser Tiefe hat — 1 bei Tiefe 1–3 (unverändertes altes Verhalten), 2 bei
  4–9, 3 bei 10–17, ab 18 dann 4. Frühe Tiefen bleiben also exakt wie vorher.
- **`floorName(i)`**: Beschriftung — `Keller`, `Erdgeschoss`, `1. Stock`,
  `2. Stock`, usw.
- **`generateStairFloor(depth, floorIdx, totalFloors)`**: erzeugt eine
  "Zwischen-Etage" — normale Maze mit Gegnern/Items (etwas schwächer besetzt
  als eine volle Tiefe, damit sich die Schwierigkeit über mehrere Etagen
  nicht unnötig aufschaukelt), aber **kein Boss, kein Schloss, kein echter
  Ausgang**. Stattdessen eine Treppe hoch (`'U'`) — nach exakt demselben
  Prinzip wie der bisherige einfache Ausgang platziert: `findDoorCell()` +
  `sealExtraApproaches()` sorgen für eine Tür am Kartenrand mit garantiert
  genau einem Zugang.
- **`generateProceduralSite(depth)`**: baut alle Etagen eines Standorts.
  Die **oberste** Etage ist unverändert `generateProceduralLevel(depth)` —
  also inklusive Vorraum-mit-Säulen und Boss, exakt der bereits getestete
  Code von vorhin, hier nicht angefasst. Nur die Etagen darunter sind neu.
- **Treppen-Rendering**: Die Treppe ist — wie der Ausgang — eine Tür in der
  Wand, kein begehbares Bodenfeld (neuer Wandwert `5` neben `# R H X`),
  eigene pulsierende Portal-Textur (`texStairs`, grün `#0ECB81` statt cyan/
  rot), gleicher Trigger-Mechanismus wie beim Ausgang (Annäherung auf ~1
  Feld genügt, kein tatsächliches Hineinlaufen nötig — die Zelle bleibt
  physisch massiv).
- **`checkStairs()`/`climbStairs()`**: laufen wie `checkExit()` in der
  Update-Schleife mit. Beim Auslösen werden Kills/Splitter/Zeit der
  aktuellen Etage in die Lauf-Statistik übernommen (wie beim normalen
  Tiefenwechsel), dann `startLevel()` auf die nächste Etage — Waffen/HP/
  Munition bleiben erhalten. Absicherung gegen Mehrfachauslösung während der
  laufenden Fade-Transition über die schon vorhandene `fadeBusy`-Sperre.
- **Minimap**: Die Treppe wird — sobald durch den Nebel des Krieges entdeckt
  — grün markiert, genau wie der (rot markierte) gesperrte Ausgang.
- **Bugfix nebenbei**: `exitCell`/`stairsCell` wurden vorher nie
  zurückgesetzt, wenn eine neue Karte kein `X`/`U` enthielt — dadurch hätte
  auf einer Etage ohne Ausgang der `checkExit()`-Check versehentlich mit der
  Zellposition der *vorherigen* Karte weitergerechnet. Jetzt werden beide zu
  Beginn jeder `parseLevel()` explizit genullt.

### Testergebnis (Node-Simulation, kein Browsertest)

3000 komplette Standorte (Tiefe 1–30, alle Größenstufen, bis zu 4 Etagen
pro Standort) durchsimuliert:
- **0 abgeschnittene Kartenteile** auf irgendeiner Etage.
- **Jede Nicht-oberste Etage** hat exakt eine Treppe, keinen Ausgang, kein
  Schloss.
- **Jede oberste Etage** hat exakt einen Ausgang, Boss ist immer da, wo
  `Tiefe % 3 === 0` gilt — unverändert zur bisherigen Logik.
- Generierung eines kompletten Standorts dauert im Schnitt ~4ms — unkritisch,
  da nur einmal pro Standort (nicht pro Frame) nötig.

### Bekannte offene Punkte zu diesem Feature

- **Kein Browsertest** — nur Grid-Ebene simuliert. Ob sich das Treppen-Portal
  in der 3D-Ansicht optisch klar von der normalen Ausgangstür unterscheidet
  und ob die Balance (Gegnerdichte pro Zwischen-Etage) sich richtig anfühlt,
  ist ungeprüft.
- Aktuell geht es nur "hoch" (Keller → Erdgeschoss → 1. Stock → …), keine
  Abzweigungen oder "runter"-Treppen. Wäre als nächster Schritt möglich,
  ist aber bewusst nicht eingebaut, um die erste Version einfach zu halten.
- Die Werte in `floorsForDepth()` (ab welcher Tiefe wie viele Etagen) und die
  Gegnerdichte in `generateStairFloor()` sind erste Schätzwerte, keine im
  Spiel getesteten Balance-Werte.

## Nachbesserung: Etagen nur in der Anlage + blinkende Server-Racks

Auf Rückmeldung angepasst: "Etagen" (Keller/Erdgeschoss/Stock) unter offenem
Himmel ergeben keinen Sinn — man kann in der Wüste/Schlucht/im Dschungel
nicht "ein Gebäude hochklettern". Deshalb jetzt:

- **`floorsForDepth(depth)`** prüft zuerst das Biom dieser Tiefe
  (`biomeForDepth(depth)`). Ist es ein Außenbiom (`BIOMES[...].outdoor`,
  also Schlucht/Wüste/Dschungel), bleibt der Standort **immer einstöckig**
  — unabhängig von der Tiefenzahl. Nur die Anlage (`facility`, Innenbereich,
  Server-Räume) bekommt die Etagen-Staffelung wie bisher (1 → 2 → 3 → 4 ab
  Tiefe 4/10/18).
- **Blinkende Server-Racks** (nur im Anlage-Biom, also passend zum
  "Serverraum"-Thema): Die Rack-Wand (`texRack`, Wandtyp `R`) hat jetzt 4
  vorgerenderte Frames mit unterschiedlichen LED-Zuständen/-Farben
  (`RACK_FRAMES`, erzeugt über `makeRackFrame(seed)` — identischer
  Panel-Hintergrund, aber eigene unabhängig gewürfelte LEDs pro Frame).
  In `renderWalls()` wird für Rack-Zellen im Anlage-Biom der Frame aus
  Zeit **plus** einem Hash der Zellposition gewählt — dadurch blinken
  nicht alle Racks im Gleichtakt, sondern phasenversetzt, wie in einem
  echten Serverraum.

Kein Browsertest — nur die Frame-Auswahl-Formel numerisch geprüft (bleibt
immer im gültigen Bereich 0–3, keine NaN, unterschiedliche Zellen bekommen
unterschiedliche Phasen). Ob das Blinktempo (Faktor `2.2`) und die
LED-Dichte gut aussehen, lässt sich nur im Browser beurteilen — bei Bedarf
in `makeRackFrame()` (Wahrscheinlichkeit `rl()<.62` für "an") bzw. in der
Frame-Formel in `renderWalls()` nachjustieren.

### Noch offen (auf Rückfrage, nicht umgesetzt)

Zusätzlich gewünscht: Displays/Schilder im Level, die die **Etagennummer**
anzeigen (nicht nur der HUD-Text oben, sondern ein sichtbares Objekt in der
3D-Welt). Das ist ein separates, etwas größeres Stück Arbeit — braucht eine
gepixelte Ziffern-/Segmentanzeige-Schrift, die es im Spiel noch nicht gibt.
Auf Rückfrage zurückgestellt, um erst zu klären, wie aufwändig das werden
soll (z. B. einfache 7-Segment-Optik neben dem Spawnpunkt vs. mehrere
Anzeigen verteilt in der Karte).

## Nachbesserung 2: Mehrere Etagen-Anzeigeschilder verteilt in der Karte

Auf Rückfrage gewünscht: nicht nur ein Schild am Spawn, sondern mehrere
kleine Displays über die Karte verteilt, die die aktuelle Etage anzeigen.

- **Anzeige im Fahrstuhl-Schema**: Keller = `-1`, Erdgeschoss = `0`,
  1. Stock = `1`, 2. Stock = `2` usw. (`f.signDigit = f.floorIdx - 1`).
- **`SEG_DIGITS`/`drawSegChar()`/`makeFloorSignTex()`**: kleine gepixelte
  7-Segment-Ziffernschrift (wie eine LED-Anzeige), unterstützt `0`–`9` und
  `-`. `SIGN_TEX` hält fertige Texturen für die Werte `-1` bis `3` vor.
- **`scatterFloorSigns(mapRows, count)`**: rein kosmetische
  Nachbearbeitung einer fertigen Karte — sucht normale, bereits massive
  Wandzellen (`#`/`R`/`H`), die an mindestens eine Flurzelle angrenzen
  (also sichtbar sind), und wandelt bis zu `count` davon (mit Mindestabstand
  zueinander) in Anzeige-Schilder (`'D'`, neuer Wandwert `6`) um. Da dabei
  nur bereits solide Wandzellen umbenannt werden (keine Flurzelle wird zur
  Wand), kann das die Erreichbarkeit der Karte nie beeinflussen.
- Läuft in `generateProceduralSite()` über **jede** Etage eines Standorts
  (Zwischen-Etagen UND die oberste Etage mit Boss/Ausgang) — aber **nur**,
  wenn der Standort wirklich mehrstöckig ist (`n>1`). Ein einstöckiger
  Sektor (jedes Außenbiom, oder Tiefe 1–3) bekommt keine Fahrstuhl-Schilder,
  das wäre dort unpassend.
- Minimap-Farbtabellen (`buildMini()`/`drawFogMini()`) um die Wandwerte `5`
  (Treppe) und `6` (Schild) ergänzt — vorher hätten diese beiden Werte dort
  ein `undefined`-`fillStyle` erzeugt (kein Absturz, aber ein stiller
  Farb-Bug). Schilder bekommen bewusst dieselbe unauffällige Minimap-Farbe
  wie normale Wände (kein Landmark, rein dekorativ); die Treppe bleibt grün
  hervorgehoben.

### Testergebnis (Node-Simulation, kein Browsertest)

900 Standorte simuliert: **0 Fehler**. Jede Karte bleibt nach dem Verteilen
der Schilder vollständig verbunden, jeder Mehr-Etagen-Standort bekommt 3–4
Schilder pro Etage, kein einstöckiger Standort bekommt versehentlich welche,
Spawn/Ausgang/Treppen-Zahl bleiben überall korrekt.

Kein Browsertest — die eigentliche Canvas-Zeichnung der Ziffern
(`makeFloorSignTex`) läuft nur im Browser (nutzt `document.createElement
('canvas')`), konnte hier nur durch Nachrechnen der Segment-Koordinaten
geprüft werden (alle Werte positiv, alles innerhalb des 64×64-Textur-
Bereichs). Ob die Ziffern wirklich lesbar/gut positioniert aussehen, bitte
im Spiel kontrollieren.

## Bekannte offene Punkte / mögliche nächste Schritte

- **Noch kein Browser-Spieltest** — nur Node-Simulation auf Grid-Ebene. Ob sich
  der Vorraum im 3D-Raycaster (Sichtlinien, Kollisionen an Säulen, Beleuchtung)
  gut anfühlt, ist ungeprüft.
- Lineare Story-Kampagne auf den Biome-Assets aufbauen (bisher nur im
  Zufallslauf genutzt).
- Balancing der Zufallslauf-Größen/Gegnerabstände weiterhin nur per Simulation
  getestet, kein echter Spieltest.
- Aus früheren Sessions offen: Muzzle-Flash am Lauf selbst, weiterer Gegnertyp
  (Sniper/Fernkämpfer), Secret Rooms, erweitertes lokales Stats-Tracking vor
  Supabase-Anbindung, Schwierigkeitsgrad-Auswahl.
